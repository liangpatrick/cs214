#include <stdio.h>
#include <stdlib.h>
#include "mymalloc.h"


int main(int argc, char *argv[])
{
    if (argc != 2)      //checks if valid input
    {
        printf("Error: Invalid Param(s): %s\n", argv[1]);
        return 1;
    }

    char patt[25];
    strcpy(patt, argv[1]);
    recursiveFind(".",patt);
    
}  