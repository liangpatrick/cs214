#include <stdio.h>
#include <stdlib.h>
#include "mymalloc.h"


// so this is the implicit free list which really is a linkedlist of all the pointers pointing to malloced stuff or freed stuff
typedef struct list
{
    int val;
    struct list *nextFree;
    
} bstNode;



// should only be called in myinit case1
size_t mostRecent = 0;
// should probably be something different, currently it is just simply 1 MB;
char* heap [1000000];

// index for where to malloc or realloc
size_t* index;

// as far as i can tell, this gets called in mymalloc and myrealloc to decide where the malloc shit should go in the "heap"
// also as far as malloc(stdio) is used in this whole project, as outlined in the pdf, we use malloc to initialize shit in myinit

void myinit(int allocAlg){
    index = 0;
    size_t length = sizeof (heap )/ sizeof(heap[0]);

//  use malloc here to update struct list???? maybe in a different method

    // def not right, but im creating this at 320 AM; simply a placeholder for now
    size_t end = 99999;
    switch (allocAlg)
    {
//  first fit
    case 0:
    // copied this from his lecture/slides; should be right with some tweaking needed.
        while((index < end)&& ( (*index & 1)|| (*index <= length)))
            index = index + (*index & -2);
        
        mostRecent = index;
        break;

//  next fit
    case 1:
    // literally the exact same thing as first fit except it starts where it left off
        index = mostRecent;
        while((index < end)&& ( (*index & 1)|| (*index <= length)))
            index = index + (*index & -2);
        
        mostRecent = index;

       
        break;

//  best fit
    case 2:
//  this is more complicated and i dont have the alertness to code this



        
        break;
    }
    return;

}

// calls myinit??? to find out where it should go
void* mymalloc(size_t size){
    if(size == 0)
        return NULL;

//  can call myinit(0), doesnt really matter
    myinit(1);
    
    

}



void myfree(void* ptr){

}

// basically it uses myinit(2)[best fit](?) to decide where it should go
void* myrealloc(void* ptr, size_t size){
 if(size == 0)
        return ptr;

    myinit(2);

}



void mycleanup(){

}
double utilization(){
    return 0;
}